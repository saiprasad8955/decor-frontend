import { useState, useCallback } from 'react';
import useSWR, { mutate } from 'swr';
import {
  Button,
  Container,
  Typography,
  Stack,
  Paper,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  IconButton,
  CircularProgress,
  Backdrop,
  TextField,
} from '@mui/material';
import { useSnackbar } from 'src/components/snackbar';
import dayjs from 'dayjs';
import { Edit, Delete, Visibility } from '@mui/icons-material';
import axiosInstance, { endpoints } from 'src/utils/axios';
import MasterDrawer from 'src/components/drawer';
import ReusableDeletePopover from 'src/components/delete-popup/delete-popup';
import { useSettingsContext } from 'src/components/settings';
import InvoiceForm from './InvoiceForm';
import InvoiceShow from './InvoiceView';

const fetcher = (url) => axiosInstance.get(url).then((res) => res.data);

export default function InvoiceView() {
  const settings = useSettingsContext();
  const [openDrawer, setOpenDrawer] = useState(false);
  const [editInvoice, setEditInvoice] = useState(null);
  const [ViewInvoice, setViewInvoice] = useState(null);
  const [viewModal, setViewModal] = useState(false);
  const [deletePopoverEl, setDeletePopoverEl] = useState(null);
  const [selectedInvoiceId, setSelectedInvoiceId] = useState(null);
  const { enqueueSnackbar } = useSnackbar();
  // Add this state with other useStates at the top
  const [searchQuery, setSearchQuery] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: invoices, error, isLoading } = useSWR(endpoints.invoice.list, fetcher);
  const { data: customers } = useSWR(endpoints.customer.list, fetcher);
  const { data: itemsList } = useSWR(endpoints.items.list, fetcher);

  const handleOpenDeletePopover = (event, id) => {
    setDeletePopoverEl(event.currentTarget);
    setSelectedInvoiceId(id);
  };

  const handleCloseDeletePopover = () => {
    setDeletePopoverEl(null);
    setSelectedInvoiceId(null);
  };

  const handleConfirmDelete = () => {
    handleDelete(selectedInvoiceId);
    handleCloseDeletePopover();
  };

  const handleAdd = useCallback(() => {
    setEditInvoice(null);
    setOpenDrawer(true);
  }, []);

  const handleSaveInvoice = useCallback(
    async (data) => {
      setIsSubmitting(true);
      try {
        let response;

        if (editInvoice) {
          response = await axiosInstance.put(`/invoice/update/${editInvoice._id}`, data);
          mutate(endpoints.invoice.list);
          if (response?.status === 200) {
            enqueueSnackbar('Invoice updated successfully.', { variant: 'success' });
          }
        } else {
          response = await axiosInstance.post('/invoice/add', data);
          mutate(endpoints.invoice.list);
          if (response?.status === 201) {
            enqueueSnackbar('Invoice added successfully.', { variant: 'success' });
          }
        }

        setOpenDrawer(false);
      } catch (err) {
        console.error('Failed to save invoice:', err);
        enqueueSnackbar(err.message || 'Something went wrong!', { variant: 'error' });
      } finally {
        setIsSubmitting(false);
      }
    },
    [editInvoice, enqueueSnackbar]
  );

  const handleDelete = useCallback(
    async (id) => {
      setIsSubmitting(true);
      try {
        await axiosInstance.delete(`/invoice/delete/${id}`);
        mutate(endpoints.invoice.list);
        enqueueSnackbar('Invoice deleted successfully.', { variant: 'success' });
      } catch (err) {
        console.error('Failed to delete customer:', err);
        enqueueSnackbar(err.message || 'Something went wrong!', { variant: 'error' });
      } finally {
        setIsSubmitting(false);
      }
    },
    [enqueueSnackbar] // No dependencies needed
  );

  if (error) {
    return (
      <Container>
        <Typography variant="h4">Invoices</Typography>
        <p style={{ color: 'red', paddingTop: 100 }}>Failed to load invoices.</p>
      </Container>
    );
  }

  const filteredInvoices =
    invoices?.filter((invoice) => {
      const query = searchQuery.toLowerCase();
      const name = invoice.customerId?.name?.toLowerCase() || '';
      const sales_person = invoice.sales_person?.toLowerCase() || '';
      const final_amount = invoice.final_amount?.toString() || '';

      return (
        name.includes(query) || sales_person.includes(query) || final_amount.includes(searchQuery)
      );
    }) || [];

  return (
    <Container maxWidth={settings.themeStretch ? false : 'xl'}>
      <Stack direction="row" justifyContent="space-between" mb={3}>
        <Typography variant="h4">Invoices</Typography>
        <Button variant="contained" color="primary" onClick={handleAdd}>
          Add Invoice
        </Button>
      </Stack>

      <div>
        <TextField
          fullWidth
          variant="outlined"
          placeholder="Search by customer name, sales person name"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          sx={{ mb: 3 }}
        />
      </div>
      <Paper>
        {isLoading ? (
          <Stack alignItems="center" py={3}>
            <CircularProgress />
          </Stack>
        ) : (
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Customer</TableCell>
                <TableCell>Sales Person</TableCell>
                <TableCell>Invoice Date</TableCell>
                <TableCell>Final Amount</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredInvoices?.length > 0 ? (
                filteredInvoices.map((invoice) => (
                  <TableRow key={invoice._id}>
                    <TableCell>{invoice.customerId?.name}</TableCell>
                    <TableCell>{invoice.sales_person}</TableCell>
                    <TableCell>{new Date(invoice.invoice_date).toLocaleDateString()}</TableCell>
                    <TableCell>₹{invoice.final_amount.toFixed(2)}</TableCell>
                    <TableCell align="right">
                      <IconButton
                        color="primary"
                        onClick={() => {
                          const invoiceD = {
                            _id: invoice._id,
                            customerId: invoice.customerId._id,
                            sales_person: invoice.sales_person,
                            invoice_date: dayjs(invoice.invoice_date),
                            delivery_date: dayjs(invoice.delivery_date),
                            description: invoice.description,
                            items: invoice.items.map((itemObj) => ({
                              item: itemObj.item._id,
                              quantity: itemObj.quantity,
                              rate: itemObj.rate,
                              tax: itemObj.tax,
                              total: itemObj.total,
                            })),
                            discount: invoice.discount,
                          };
                          setEditInvoice(invoiceD);
                          setOpenDrawer(true);
                        }}
                      >
                        <Edit />
                      </IconButton>
                      <IconButton
                        color="error"
                        onClick={(e) => handleOpenDeletePopover(e, invoice._id)}
                      >
                        <Delete />
                      </IconButton>
                      <IconButton
                        // color="error"
                        onClick={() => {
                          const invoiceD = {
                            _id: invoice._id,
                            customerId: invoice.customerId._id,
                            sales_person: invoice.sales_person,
                            invoice_date: dayjs(invoice.invoice_date),
                            delivery_date: dayjs(invoice.delivery_date),
                            description: invoice.description,
                            items: invoice.items.map((itemObj) => ({
                              item: itemObj.item._id,
                              quantity: itemObj.quantity,
                              rate: itemObj.rate,
                              tax: itemObj.tax,
                              total: itemObj.total,
                            })),
                            discount: invoice.discount,
                          };
                          setViewInvoice(invoiceD);
                          setViewModal(true);
                        }}
                      >
                        <Visibility />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={5} align="center" sx={{ py: 4 }}>
                    <Typography variant="body1">
                      {' '}
                      No customers found matching <strong>&quot;{searchQuery}&quot;</strong>.
                    </Typography>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        )}
      </Paper>

      <MasterDrawer
        open={openDrawer}
        onClose={() => setOpenDrawer(false)}
        title={editInvoice ? 'Update Invoice' : 'Add Invoice'}
      >
        <InvoiceForm
          initialData={editInvoice || {}}
          onSubmit={handleSaveInvoice}
          onClose={() => setOpenDrawer(false)}
          customers={customers}
          itemsList={itemsList}
        />
      </MasterDrawer>

      <ReusableDeletePopover
        open={deletePopoverEl}
        onClose={handleCloseDeletePopover}
        onConfirm={handleConfirmDelete}
        title="Delete Invoice?"
        description="Are you sure you want to delete this invoice?"
      />
      <Backdrop
        open={isSubmitting}
        sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
      >
        <CircularProgress color="inherit" />
      </Backdrop>

      <MasterDrawer open={viewModal} onClose={() => setViewModal(false)} title="Invoice View">
        <InvoiceShow
          invoiceData={ViewInvoice}
          customers={customers}
          itemsList={itemsList}
          onClose={() => setViewModal(false)}
        />
      </MasterDrawer>
    </Container>
  );
}
